<?php
    header("Location: ./Page1_unprotected.php");
?>