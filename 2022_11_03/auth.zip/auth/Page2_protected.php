<?php include('./controllers/_rememberOriginPage.php'); ?>
<?php include('./controllers/_protect.php'); ?>
<!doctype html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="./css/style.css">
        <title>Page 2</title>
        <!-- jQuery + Bootstrap JS -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body> 
        <?php include('header.php'); ?>
        <div class="App">
            <div class="vertical-center">
                <div class="inner-block">
                    <div class="row">
                        <div class="col">
                            <label>Id</label>
                        </div>
                        <div class="col">
                            <p>
                                <?php echo $_SESSION['logged_user']['id'] ?? ""; ?>
                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label>Prénom</label>
                        </div>
                        <div class="col">
                            <p>
                                <?php echo $_SESSION['logged_user']['firstname'] ?? ""; ?>
                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label>Nom</label>
                        </div>
                        <div class="col">
                            <p>
                                <?php echo $_SESSION['logged_user']['lastname'] ?? ""; ?>
                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label>Email</label>
                        </div>
                        <div class="col">
                            <p>
                                <?php echo $_SESSION['logged_user']['email'] ?? ""; ?>
                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label>Mobile</label>
                        </div>
                        <div class="col">
                            <p>
                                <?php echo $_SESSION['logged_user']['mobilenumber'] ?? ""; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>