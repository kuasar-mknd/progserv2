# Exemple d'authentification PHP

Avant d'exécuter le code, il est nécessaire d'avoir : 

- Une base de données `MySql` nommée `authdb` contenant la table suivante : 

```sql
CREATE TABLE users (
  id int AUTO_INCREMENT PRIMARY KEY,
  firstname varchar(100) NOT NULL,
  lastname varchar(100) NOT NULL,
  email varchar(50) NOT NULL,
  mobilenumber varchar(50) NOT NULL,
  password varchar(255) NOT NULL,
  token varchar(255) NOT NULL,
  is_active int DEFAULT 0,
  date_time date NOT NULL
);
```

- La base de données `authdb` avec un utilisateur `phpuser` avec le mot de passe `H2e0i2g-v2d3` disposant de tous les privilèges.

> Remarque : vous pouvez évidement appeler votre base de données, votre table, votre utilisateur et son mot de passe comme bon vous semble, mais il faudra modifier le contenu du fichier \config\db.ini :wink:
>
> \config\db.ini
>
> ```ini
> dsn = 'mysql:dbname=authdb;host=localhost;charset=utf8'
> hostname = "localhost";
> username = "phpuser";
> password = "H2e0i2g-v2d3";
> dbname = "authdb";
> ```

- Le serveur SMTP Mailhog qui tourne (pour l'envoi du mail)

  > Rappel :  Le serveur mail se consulte avec le lien http://localhost:8025
