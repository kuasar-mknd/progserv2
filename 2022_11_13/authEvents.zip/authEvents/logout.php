<?php     
    @session_start();
    $location = "index.php";
    if (isset($_SESSION["is_logged"]) && $_SESSION["is_logged"]) { 
        $location = $_SESSION['originPage'] ?? "";
        session_destroy();
    }
    header("Location:$location");
?>