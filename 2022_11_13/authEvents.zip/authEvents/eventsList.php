<!doctype html>
<?php 
require_once('./controllers/_rememberOriginPage.php');
require_once('./config/autoload.php');

function monthToFrench($date) {
    $sdate1 = str_replace("Jan", "Jan", $date);
    $sdate2 = str_replace("Feb", "Fév", $sdate1);
    $sdate3 = str_replace("Mar", "Mar", $sdate2);
    $sdate4 = str_replace("Apr", "Avr", $sdate3);
    $sdate5 = str_replace("May", "Mai", $sdate4);
    //$sdate6 = str_replace("Jun","Jun",$sdate5);
    //$sdate7 = str_replace("Jul","Jul",$sdate6);
    $sdate8 = str_replace("Aug", "Aoû", $sdate5);
    //$sdate9 = str_replace("Sep","Sep",$sdate8);
    $sdate10 = str_replace("Oct", "Oct", $sdate8);
    $sdate11 = str_replace("Nov", "Nov", $sdate10);
    $sdate12 = str_replace("Dec", "Déc", $sdate11);
    $date1 = str_replace("January", "Janvier", $sdate12);
    $date2 = str_replace("February", "Février", $date1);
    $date3 = str_replace("March", "Mars", $date2);
    $date4 = str_replace("April", "Avril", $date3);
    $date5 = str_replace("May", "Mai", $date4);
    $date6 = str_replace("June", "Juin", $date5);
    $date7 = str_replace("July", "Juillet", $date6);
    $date8 = str_replace("August", "Août", $date7);
    $date9 = str_replace("September", "Septembre", $date8);
    $date10 = str_replace("October", "Octobre", $date9);
    $date11 = str_replace("November", "Novembre", $date10);
    $date12 = str_replace("December", "Décembre", $date11);
    return $date12;
}

use ch\comem\DbManager;
$db = new DbManager();
$events = $db->getNextEventsDatas();
?>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="./css/style.css">
        <title>Page 1</title>
        <!-- jQuery + Bootstrap JS -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
        <?php include('header.php'); ?>
        <div class="event-schedule-area-two">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade active show" id="home" role="tabpanel">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="text-center" scope="col">Date</th>
                                                <th scope="col">Horaire</th>
                                                <th scope="col">Lieu</th>
                                                <th scope="col">Participant(s)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($events as $event): ?>
                                                <?php
                                                $dmy = explode(" ", monthToFrench(date('j F Y', strtotime($event["date_time"]))));
                                                ?>
                                                <tr class="inner-box">
                                                    <th scope="row">
                                                        <div class="event-date">
                                                            <span><?= $dmy[0]; ?></span>
                                                            <p><?= $dmy[1]; ?></p>
                                                            <p><?= $dmy[2]; ?></p>
                                                        </div>
                                                    </th>
                                                    <td>
                                                        <div class="event-wrap">
                                                            <div class="meta">
                                                                <div class="time">
                                                                    <span><?= substr($event["begin_time"], 0, -3); ?> - <?= substr($event["end_time"], 0, -3); ?></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="venue">
                                                            <span><?= $event["venue"]; ?></span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div>
                                                            <?php
                                                            $users = $db->getRegistredUsers($event["id"]);
                                                            ?>
                                                            <?php foreach ($users as $user): ?>
                                                                <div>
                                                                    <?= $user["lastname"] . " " . $user["firstname"]; ?>
                                                                </div>
                                                            <?php endforeach; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>