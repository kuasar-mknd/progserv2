<?php
    header("Location: ./eventsList.php");
?>