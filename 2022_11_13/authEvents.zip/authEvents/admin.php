<?php
require_once('./controllers/_onlyAdmin.php');
require_once('./controllers/adminValidation.php');

use ch\comem\DbManager;

$db = new DbManager();
$events = $db->getNextEventsDatas();
?>
<html>
    <head>
        <style>
            form  {
                display: table;
            }
            p     {
                display: table-row;
            }
            label {
                display: table-cell;
            }
            input {
                display: table-cell;
            }
        </style>
        <script>
            if (typeof window.history.pushState === 'function') {
                window.history.pushState({}, "Hide", "admin.php");
            }
        </script>
    </head>
    <body>
        <?php
        $users = $db->getUsers();
        echo "<h3>Users</h3>";
        foreach ($users as $user) {
            $userId = $user['id'];
            $updateLink = "<a href='?updateUser&id_user=$userId'>(mettre à jour)</a>";
            $removeLink = "<a href='?removeUser&id_user=$userId'>(supprimer)</a>";
            echo $user["lastname"] . ", " . $user["firstname"] . ", ", $user["email"], ", ", $user["mobilenumber"], " ", $updateLink, " " ,$removeLink, "<br>";
        }
        ?>
        <br>
        <form action='' method='POST'>
            <input type='hidden' name='<?= $userAction; ?>User'/>
            <input type='hidden' name='id_user' value='<?= $id_user; ?>'/>
            <p>
                <label for='firstname'>Prénom:</label>
                <input type='text' id='firstname' name='firstname' value='<?= $firstname; ?>' required>
            </p>
            <p>
                <label for='lastname'>Nom:</label>
                <input type='text' id='lastname' name='lastname' value='<?= $lastname; ?>' required>
            </p>
            <p>
                <label for='email'>Email:</label>
                <input type='email' id='email' name='email' value='<?= $email; ?>' required>
            </p>
            <p>
                <label for='mobile'>Mobile:</label>
                <input type='text' id='mobile' name='mobile' value='<?= $mobile; ?>' required>
            </p>
            <p>
                <label for='password'>Mot de passe:</label>
                <input type='password' id='password' name='password' <?= $required; ?>>
            </p>
            <p>
                <input type='submit' value="<?= $userButtonName; ?>">
            </p>
        </form>
        <br><br>
        <?php
        echo "<h3>Évènements</h3>";
        foreach ($events as $event) {
            echo "Sortie du ";
            echo date('j.m.y', strtotime($event["date_time"])), " de ";
            echo substr($event["begin_time"], 0, -3), "-", substr($event["end_time"], 0, -3), " à ";
            echo $event["venue"], " ";
            $eventId = $event['id'];
            $updateLink = "<a href='?updateEvent&id_event=$eventId'>(mettre à jour)</a>";
            $removeLink = "<a href='?removeEvent&id_event=$eventId'>(supprimer)</a>";
            echo $updateLink, " ", $removeLink, "<br>";
        }
        ?>
        <br>
        <form action='' method='POST'>
            <input type='hidden' name='<?= $eventAction; ?>Event'/>
            <input type='hidden' name='id_event' value='<?= $id_event; ?>'/>
            <p>
                <label for='venue'>Lieu:</label>
                <input type='text' id='venue' name='venue' value='<?= $venue; ?>' required>
            </p>
            <p>
                <label for='date'>Date:</label>
                <input type='date' id='date' name='date' min='<?= $date; ?>' value='<?= $date; ?>'>
            </p>
            <p>
                <label for='stime'>Heure début:</label>
                <input type='time' id='stime' name='stime' min='00:00' max='23:59' value='<?= $stime; ?>' required>
            </p>
            <p>
                <label for='etime'>Heure fin:</label>
                <input type='time' id='etime' name='etime' min='00:00' max='23:59' value='<?= $etime; ?>' required>
            </p>
            <p>
                <input type='submit' value="<?= $eventButtonName; ?>">
            </p>
        </form>
        <a href='EventsList.php'>retour</a>
    </body>
</html>