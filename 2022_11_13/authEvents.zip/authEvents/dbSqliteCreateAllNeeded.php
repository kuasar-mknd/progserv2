<?php

$db = new SQLite3('authdbevent.sqlite');
if (!$db) {
    echo $db->lastErrorMsg();
} else {
    echo "La connection à la base de données a été effectuée avec succès", "<br>";
}

$sql = <<<'COMMANDE_SQL'
CREATE TABLE users (
  id integer PRIMARY KEY AUTOINCREMENT,
  firstname varchar(30) NOT NULL,
  lastname varchar(30) NOT NULL,
  email varchar(50) NOT NULL,
  mobilenumber varchar(10) NOT NULL,
  password varchar(255) NOT NULL,
  date_time date NOT NULL,
  is_admin int DEFAULT 0
);
    
CREATE TABLE events (
    id integer PRIMARY KEY AUTOINCREMENT,
    venue varchar(30),
    date_time date NOT NULL,
    begin_time time NOT NULL,
    end_time time NOT NULL
);

CREATE TABLE users_events_registration (
    fk_user integer NOT NULL, 
    fk_event integer NOT NULL, 
    PRIMARY KEY(fk_user, fk_event), 
    FOREIGN KEY(fk_user) REFERENCES users(id) ON DELETE CASCADE, 
    FOREIGN KEY(fk_event) REFERENCES events(id) ON DELETE CASCADE
);

/* Mot de passe : Testtest1$   */
INSERT INTO users (firstname, lastname, email, mobilenumber, password, date_time, is_admin) VALUES ('Test', 'Test', 'test.test@test.ch', '0791234567','$2y$10$rqqrJKqB441HNcsBm8JhWOpOCtK2xrunrHX5Rn4Zf34Nb9UyuZ.aK','2022-11-17',1);
/* Mot de passe : Joebar1$   */
INSERT INTO users (firstname, lastname, email, mobilenumber, password, date_time, is_admin) VALUES ('Joe', 'Bar', 'joe.bar@motard.ch', '0791112233','$2y$10$6Etbsuml8LlPOzED3XnVfOm.8nr7fdwQ8J7QxpAoHZuF.pCicFuH2','2022-11-17',0);
/* Mot de passe : Zoedumoulin1$   */
INSERT INTO users (firstname, lastname, email, mobilenumber, password, date_time, is_admin) VALUES ('Zoe', 'Dumoulin', 'zoe.dumoulin@test.ch', '0798887766','$2y$10$4Z/vSHVtqGaz1NeRatyTJuLIGlfrTQhWFfEesa2Ou3qQK3UeNQu1W','2022-11-17',0);

INSERT INTO events (venue, date_time, begin_time, end_time) VALUES ("Zurich", '2022-11-28', TIME("10:00:00"), TIME("12:00:00"));
INSERT INTO events (venue, date_time, begin_time, end_time) VALUES ("Berne", '2022-11-29', TIME("14:00:00"), TIME("15:00:00"));
INSERT INTO events (venue, date_time, begin_time, end_time) VALUES ("Yerdon", '2022-11-30', TIME("17:00:00"), TIME("19:00:00"));
INSERT INTO users_events_registration (fk_user, fk_event) VALUES (1,1);
INSERT INTO users_events_registration (fk_user, fk_event) VALUES (1,2);
INSERT INTO users_events_registration (fk_user, fk_event) VALUES (1,3);
INSERT INTO users_events_registration (fk_user, fk_event) VALUES (2,1);
INSERT INTO users_events_registration (fk_user, fk_event) VALUES (2,3);
INSERT INTO users_events_registration (fk_user, fk_event) VALUES (3,1);
COMMANDE_SQL;

$ret = $db->exec($sql);
if (!$ret) {
    echo $db->lastErrorMsg();
} else {
    echo "Les tables ainsi que les données ont été créées avec succès", "<br>";
}
$db->close();
?>