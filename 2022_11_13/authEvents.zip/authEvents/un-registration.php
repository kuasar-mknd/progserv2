<?php
require_once('./controllers/un-registrationValidation.php');

use ch\comem\DbManager;

$db = new DbManager();
$events = $db->getNextEventsDatas();
?>
<html>
    <head>
        <script>
            if (typeof window.history.pushState === 'function') {
                window.history.pushState({}, "Hide", "un-registration.php");
            }
        </script>
    </head>
    <body>
        <?php
        foreach ($events as $event) {
            $registrationLink = "";
            $unregistrationLink = "";
            echo "Sortie du ";
            echo date('j.m.y', strtotime($event["date_time"])), " de ";
            echo substr($event["begin_time"], 0, -3), "-", substr($event["end_time"], 0, -3), " à ";
            echo $event["venue"];
            $users = $db->getRegistredUsers($event["id"]);
            $usersTab = array();
            foreach ($users as $user) {
                $usersTab[] = $user["lastname"] . " " . $user["firstname"];
            }
            if (isset($_SESSION['is_logged']) && $_SESSION['is_logged']) {
                $userId = $_SESSION['logged_user']['id'];
                $eventId = $event['id'];
                if ($db->existRegistration($userId, $eventId)) {
                    $unregistrationLink = "<a href='?unregistration&id_user=$userId&id_event=$eventId'>(se déinscrire)</a>";
                } else {
                    $registrationLink = "<a href='?registration&id_user=$userId&id_event=$eventId'>(s'inscrire)</a>";
                }
            }
            echo " (Participants : ", implode(", ", $usersTab), ") ", $unregistrationLink, $registrationLink, "<br>";
        }
        ?>
        <br>
        <a href='EventsList.php'>retour</a>
    </body>
</html>