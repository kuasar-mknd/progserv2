<?php

require_once('./config/autoload.php');

use ch\comem\DbManager;

$id_user = -1;
$firstname = "";
$lastname = "";
$email = "";
$mobile = "";
$userAction = "add";
$userButtonName = "Ajoute l'utilisateur";
$required = "required";

$id_event = -1;
$venue = "";
$date = date('Y-m-d');
$stime = "--:--";
$etime = "--:--";
$eventAction = "add";
$eventButtonName = "Ajoute l'évènement";

$db = new DbManager();
if (filter_has_var(INPUT_GET, 'removeUser')) {
    $id_user = filter_input(INPUT_GET, 'id_user', FILTER_SANITIZE_NUMBER_INT);
    $db->deleteUser($id_user);
} else if (filter_has_var(INPUT_GET, 'removeEvent')) {
    $id_event = filter_input(INPUT_GET, 'id_event', FILTER_SANITIZE_NUMBER_INT);
    $db->deleteEvent($id_event);
} else if (filter_has_var(INPUT_POST, 'addEvent')) {
    $venue = filter_input(INPUT_POST, 'venue', FILTER_UNSAFE_RAW);
    $date = filter_input(INPUT_POST, 'date', FILTER_UNSAFE_RAW);
    $stime = filter_input(INPUT_POST, 'stime', FILTER_UNSAFE_RAW) . ":00";
    $etime = filter_input(INPUT_POST, 'etime', FILTER_UNSAFE_RAW) . ":00";
    $db->storeEvent($venue, $date, $stime, $etime);
}else if (filter_has_var(INPUT_POST, 'addUser')) {
    $firstname = filter_input(INPUT_POST, 'firstname', FILTER_UNSAFE_RAW);
    $lastname = filter_input(INPUT_POST, 'lastname', FILTER_UNSAFE_RAW);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $mobile = filter_input(INPUT_POST, 'mobile', FILTER_UNSAFE_RAW);
    $password_hash = password_hash(filter_input(INPUT_POST, 'mobile', FILTER_UNSAFE_RAW), PASSWORD_BCRYPT);
    $db->storeUser($firstname, $lastname, $email, $mobile, $password_hash);
} else if (filter_has_var(INPUT_POST, 'updateEvent')) {
    $id_event = filter_input(INPUT_POST, 'id_event', FILTER_SANITIZE_NUMBER_INT);
    $venue = filter_input(INPUT_POST, 'venue', FILTER_UNSAFE_RAW);
    $date = filter_input(INPUT_POST, 'date', FILTER_UNSAFE_RAW);
    $stime = filter_input(INPUT_POST, 'stime', FILTER_UNSAFE_RAW) . ":00";
    $etime = filter_input(INPUT_POST, 'etime', FILTER_UNSAFE_RAW) . ":00";
    $db->updateEvent($id_event, $venue, $date, $stime, $etime);
    $venue = "";
    $date = date('Y-m-d');
    $stime = "--:--";
    $etime = "--:--";
    $eventAction = "add";
    $eventButtonName = "Ajoute l'évènement";
    $id_event = -1;
} else if (filter_has_var(INPUT_GET, 'updateEvent')) {
    $eventAction = "update";
    $id_event = filter_input(INPUT_GET, 'id_event', FILTER_SANITIZE_NUMBER_INT);
    $row = $db->getEventDatas($id_event);
    $venue = $row["venue"];
    $date = $row["date_time"];
    $stime = substr($row["begin_time"], 0, -3);
    $etime = substr($row["end_time"], 0, -3);
    $eventButtonName = "Met à jour l'évènement";
} else if (filter_has_var(INPUT_POST, 'updateUser')) {
    $id_user = filter_input(INPUT_POST, 'id_user', FILTER_SANITIZE_NUMBER_INT);
    $firstname = filter_input(INPUT_POST, 'firstname', FILTER_UNSAFE_RAW);
    $lastname = filter_input(INPUT_POST, 'lastname', FILTER_UNSAFE_RAW);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $mobile = filter_input(INPUT_POST, 'mobile', FILTER_UNSAFE_RAW);
    $password = filter_input(INPUT_POST, 'password', FILTER_UNSAFE_RAW);
    if (!empty($password)) $password = password_hash($password, PASSWORD_BCRYPT);
    $db->updateUser($id_user, $firstname, $lastname, $email, $mobile, $password);
    $firstname = "";
    $lastname = "";
    $email = "";
    $mobile = "";
    $userAction = "add";
    $userButtonName = "Ajoute l'utilisateur";
    $id_event = -1;
} else if (filter_has_var(INPUT_GET, 'updateUser')) {
    $userAction = "update";
    $id_user = filter_input(INPUT_GET, 'id_user', FILTER_SANITIZE_NUMBER_INT);
    $row = $db->getUserDatasBis($id_user);
    $firstname = $row["firstname"];
    $lastname = $row["lastname"];
    $email = $row["email"];
    $mobile = $row["mobilenumber"];
    $userButtonName = "Met à jour l'utilisateur";
    $required = "";
}
?>