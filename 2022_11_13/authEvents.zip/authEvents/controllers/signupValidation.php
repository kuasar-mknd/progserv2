<?php

require_once('./config/autoload.php');

use ch\comem\DbManager;

$firstnameErr = $lastnameErr = $emailErr = $mobileErr = $passwordErr = $emailValidationErr = $successMsg = "";

if (filter_has_var(INPUT_POST, 'submit')) {

    $firstname = filter_input(INPUT_POST, 'firstname', FILTER_UNSAFE_RAW);
    $lastname = filter_input(INPUT_POST, 'lastname', FILTER_UNSAFE_RAW);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $mobilenumber = filter_input(INPUT_POST, 'mobilenumber', FILTER_UNSAFE_RAW);
    $password = filter_input(INPUT_POST, 'password', FILTER_UNSAFE_RAW);
    $validationError = false;
    
    if (empty($firstname)) {
        $firstnameErr = '<div class="alert alert-danger">
                    Il faut un prénom.
                </div>';
        $validationError = true;
    } else if (!preg_match("/[A-Z][a-zäàâèêéïöôüç]+([- ]?[A-Z][a-zäàâèêéïöôüç]+)?/", $firstname)) {
        $firstnameErr = '<div class="alert alert-danger">
                            Le prénom ne doit contenir que des lettres, tirets et espaces
                        </div>';
        $validationError = true;
    }

    if (empty($lastname)) {
        $lastnameErr = '<div class="alert alert-danger">
                Il faut un nom.
            </div>';
        $validationError = true;
    } else if (!preg_match("/[A-Z][a-zäàâèêéïöôüç]+([- ]?[A-Z][a-zäàâèêéïöôüç]+)?/", $lastname)) {
        $lastnameErr = '<div class="alert alert-danger">
                            Le nom ne doit contenir que des lettres, tirets et espaces
                        </div>';
        $validationError = true;
    }

    $db = new DbManager();
    if (!$email) {
        $emailErr = "<div class='alert alert-danger'>
                            L'email doit être valide !
                        </div>";
        $validationError = true;
    } else if ($db->emailExist($email)) {
        $emailErr = "<div class='alert alert-danger'>
                            Cet email est déjà utilisé !
                        </div>";
        $validationError = true;
    }

    if (empty($mobilenumber)) {
        $mobileErr = '<div class="alert alert-danger">
            Il faut un numéro de mobile.
        </div>';
        $validationError = true;
    } else if (!preg_match("/^[0-9]{10}+$/", $mobilenumber)) {
        $mobileErr = '<div class="alert alert-danger">
                            Le numéro de mobile doit contenir 10 chiffres.
                        </div>';
        $validationError = true;
    }

    if (empty($password)) {
        $passwordErr = '<div class="alert alert-danger">
            Il faut un mot de passe.
        </div>';
        $validationError = true;
    } else if (!preg_match("/^(?=.*\d)(?=.*[@#\-_$%^&+=§!\?])(?=.*[a-z])(?=.*[A-Z])[0-9A-Za-z@#\-_$%^&+=§!\?]{8,20}$/", $password)) {
        $passwordErr = '<div class="alert alert-danger">
                        Le mot de passe doit avoir entre 8 et 20 caractères et contenir au moins : <br>- un caractère spécial,<br> - une minuscule,<br> - une majuscule,<br> - et un chiffre.
                    </div>';
        $validationError = true;
    }

    if (!$validationError) {
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $ok = $db->storeUser($firstname, $lastname, $email, $mobilenumber, $password_hash);

        if (!$ok) {
            die("Problème d'enregistrement de l'utilisateur dans la base de données MySql");
        } else {
            $successMsg = "<div class='alert alert-success'>
                                Votre compte a été créé !
                            </div>";
        }
    }
}
?>