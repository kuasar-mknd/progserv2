<?php
    session_start();
    require_once('./config/autoload.php');
    use ch\comem\DbManager;
    
    if (filter_has_var(INPUT_GET, 'unregistration')) {
        $id_user = filter_input(INPUT_GET, 'id_user', FILTER_SANITIZE_NUMBER_INT);
        $id_event = filter_input(INPUT_GET, 'id_event', FILTER_SANITIZE_NUMBER_INT);
        $db = new DbManager();
        $db->deleteRegistration($id_user, $id_event);
    } else if (filter_has_var(INPUT_GET, 'registration')) {
        $id_user = filter_input(INPUT_GET, 'id_user', FILTER_SANITIZE_NUMBER_INT);
        $id_event = filter_input(INPUT_GET, 'id_event', FILTER_SANITIZE_NUMBER_INT);
        $db = new DbManager();
        $db->storeRegistration($id_user, $id_event);
    }
?>