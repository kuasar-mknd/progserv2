<?php
    @session_start();
    $_SESSION["originPage"] = $_SERVER['PHP_SELF'];
?>
