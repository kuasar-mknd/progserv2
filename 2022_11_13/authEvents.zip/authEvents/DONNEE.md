# Exercice

Veuillez écrire le code nécessaire permettant à un club constitué de membres de s'inscrire à des évènements.

Le code doit permettre :

- d'ajouter ou de supprimer des membres
- d'ajouter ou de supprimer des évènements
- à un membre de pouvoir s'inscrire ou se dé-inscrire à un évènement

> Remarques :
>
> - Seul l'administrateur du site peut (après login) :
>   - ajouter ou supprimer un membre
>   - ajouter ou supprimer un évènement
> - Un membre peut (après login) s'inscrire ou se dé-inscrire à un évènement.

La page principale du site doit permettre (sans login) de visualiser les évènements à venir (triés par date) avec les inscrits (prénom nom)

Un évènement est déterminé par :

- Une date
- Un lieu
- Une heure de début
- Une heure de fin