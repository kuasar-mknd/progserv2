<?php

namespace ch\comem;

class DbManager implements I_API {

    private $db;

    public function __construct() {
        $config = parse_ini_file('config' . DIRECTORY_SEPARATOR . 'db.ini', true);
        $dsn = $config['dsn'];
        $username = $config['username'];
        $password = $config['password'];
        $this->db = new \PDO($dsn, $username, $password);
        if (!$this->db) {
            die("Problème de connection à la base de données");
        }
    }

    public function emailExist($email): bool {
        $sql = "SELECT count(*) From users WHERE email = :email;";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam('email', $email, \PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    }

    public function getUserDatas($email, $password): array {
        $sql = "SELECT * From users WHERE email = :email;";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam('email', $email, \PDO::PARAM_STR);
        $stmt->execute();
        $donnees = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        if (!$donnees) {
            $donnees[0]["email_ok"] = false;
        } else {
            if (!password_verify($password, $donnees[0]["password"])) {
                unset($donnees[0]);
                $donnees[0]["email_ok"] = true;
                $donnees[0]["password_ok"] = false;
            } else {
                $donnees[0]["email_ok"] = true;
                $donnees[0]["password_ok"] = true;
                unset($donnees[0]["password"]);
            }
        }
        return $donnees[0];
    }

    public function getUserDatasBis($id_user): array {
        $sql = "SELECT id, firstname, lastname, email, mobilenumber From users WHERE id = :id_user;";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam('id_user', $id_user, \PDO::PARAM_STR);
        $stmt->execute();
        $donnees = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        if (!$donnees) {
            $donnees[0]["id"] = -1;
        }
        return $donnees[0];
    }

    public function getEventDatas($id_event): array {
        $sql = "SELECT * From events WHERE id = :id_event;";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam('id_event', $id_event, \PDO::PARAM_STR);
        $stmt->execute();
        $donnees = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        if (!$donnees) {
            $donnees[0]["id"] = -1;
        }
        return $donnees[0];
    }

    public function storeUser($firstname, $lastname, $email, $mobile, $password_hash): bool {
        $stored = false;
        if (!empty($firstname) && !empty($lastname) && !empty($email) && !empty($mobile) && !empty($password_hash)) {
            $now = date("Y-m-d H:i:s");
            $datas = [
                'firstname' => $firstname,
                'lastname' => $lastname,
                'email' => $email,
                'mobile' => $mobile,
                'password' => $password_hash,
                'datetime' => $now,
            ];
            $sql = "INSERT INTO users (firstname, lastname, email, mobilenumber, password, date_time) VALUES "
                    . "(:firstname, :lastname, :email, :mobile, :password, :datetime)";
            $this->db->prepare($sql)->execute($datas);
            $stored = true;
        }
        return $stored;
    }

    public function storeEvent($venue, $date, $beginTime, $endTime): bool {
        $stored = false;
        if (!empty($venue) && !empty($date) && !empty($beginTime) && !empty($endTime)) {
            $datas = [
                'venue' => $venue,
                'date' => $date,
                'beginTime' => $beginTime,
                'endTime' => $endTime,
            ];
            $sql = "INSERT INTO events (venue, date_time, begin_time, end_time) VALUES "
                    . "(:venue, :date, :beginTime, :endTime)";
            $this->db->prepare($sql)->execute($datas);
            $stored = true;
        }
        return $stored;
    }

    public function updateEvent($id_event, $venue, $date, $beginTime, $endTime): bool {
        $updated = false;
        if (!empty($id_event) && !empty($venue) && !empty($date) && !empty($beginTime) && !empty($endTime)) {
            $datas = [
                'id_event' => $id_event,
                'venue' => $venue,
                'date' => $date,
                'beginTime' => $beginTime,
                'endTime' => $endTime,
            ];
            $sql = "UPDATE events SET venue=:venue, date_time=:date, begin_time=:beginTime, end_time=:endTime WHERE id=:id_event";
            $this->db->prepare($sql)->execute($datas);
            $updated = true;
        }
        return $updated;
    }

    public function updateUser($id_user, $firstname, $lastname, $email, $mobile, $password): bool {
        $updated = false;
        if (!empty($id_user) && !empty($firstname) && !empty($lastname) && !empty($email) && $mobile) {
            if (empty($password)) {
                $datas = [
                    'id_user' => $id_user,
                    'firstname' => $firstname,
                    'lastname' => $lastname,
                    'email' => $email,
                    'mobile' => $mobile,
                ];
                $sql = "UPDATE users SET firstname=:firstname, lastname=:lastname, email=:email, mobilenumber=:mobile WHERE id=:id_user";
                $this->db->prepare($sql)->execute($datas);
                $updated = true;
            } else {
                $datas = [
                    'id_user' => $id_user,
                    'firstname' => $firstname,
                    'lastname' => $lastname,
                    'email' => $email,
                    'mobile' => $mobile,
                    'password' => $password,
                ];
                $sql = "UPDATE users SET firstname=:firstname, lastname=:lastname, email=:email, mobilenumber=:mobile, password=:password WHERE id=:id_user";
                $this->db->prepare($sql)->execute($datas);
                $updated = true;
            }
        }
        return $updated;
    }

    public function existRegistration($id_user, $id_event): bool {
        $nb = -1;
        if (!empty($id_user) && !empty($id_event)) {
            $datas = [
                'fk_user' => $id_user,
                'fk_event' => $id_event,
            ];
            $sql = "SELECT count(*) FROM users_events_registration WHERE " .
                    "fk_user = :fk_user AND fk_event = :fk_event;";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($datas);
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            $nb = $rows[0]["count(*)"];
        }
        return $nb > 0;
    }

    public function storeRegistration($id_user, $id_event): bool {
        $stored = false;
        if (!empty($id_user) && !empty($id_event) && !$this->existRegistration($id_user, $id_event)) {
            $datas = [
                'fk_user' => $id_user,
                'fk_event' => $id_event,
            ];
            $sql = "INSERT INTO users_events_registration (fk_user, fk_event) VALUES "
                    . "(:fk_user, :fk_event)";
            $this->db->prepare($sql)->execute($datas);
            $stored = true;
        }
        return $stored;
    }

    public function deleteRegistration($id_user, $id_event): bool {
        $deleted = false;
        if (!empty($id_user) && !empty($id_event)) {
            $datas = [
                'fk_user' => $id_user,
                'fk_event' => $id_event,
            ];
            $sql = "DELETE FROM users_events_registration WHERE fk_user = :fk_user AND fk_event = :fk_event;";
            $this->db->prepare($sql)->execute($datas);
            $deleted = true;
        }
        return $deleted;
    }

    public function deleteEvent($id_event): bool {
        $deleted = false;
        if (!empty($id_event)) {
            $datas = [
                'id_event' => $id_event,
            ];
            $sql = "DELETE FROM events WHERE id = :id_event;";
            $this->db->prepare($sql)->execute($datas);
            $deleted = true;
        }
        return $deleted;
    }

    public function deleteUser($id_user): bool {
        $deleted = false;
        if (!empty($id_user)) {
            $datas = [
                'id_user' => $id_user,
            ];
            $sql = "DELETE FROM users WHERE id = :id_user;";
            $this->db->prepare($sql)->execute($datas);
            $deleted = true;
        }
        return $deleted;
    }

    public function getNextEventsDatas(): array {
        $now = date('Y-m-d');
        $sql = "SELECT * FROM events WHERE date_time >= '" . $now . "' order by date_time ASC, begin_time ASC, end_time ASC;";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $datas = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $datas;
    }

    public function getRegistredUsers($id_event): array {
        $sql = "SELECT id, firstname, lastname FROM users, users_events_registration WHERE users.id = users_events_registration.fk_user AND fk_event = :id_event ORDER BY lastname ASC, firstname ASC;";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam('id_event', $id_event, \PDO::PARAM_STR);
        $stmt->execute();
        $donnees = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $donnees;
    }

    public function getUsers(): array {
        $sql = "SELECT id, firstname, lastname, email, mobilenumber FROM users ORDER BY lastname ASC, firstname ASC;";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $donnees = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $donnees;
    }
}
