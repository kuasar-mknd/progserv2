<?php

namespace ch\comem;

interface I_API {
    function storeUser($firstname, $lastname, $email, $mobile, $password_hash): bool;
    public function emailExist($email): bool;
    public function getUserDatas($email, $password): array;
    public function getUserDatasBis($id_user): array;
    public function storeEvent($venue, $date, $beginTime, $endTime): bool;
    public function existRegistration($id_user, $id_event): bool;
    public function storeRegistration($id_user, $id_event): bool;
    public function deleteRegistration($id_user, $id_event): bool;
    public function deleteEvent($id_event): bool;
    public function deleteUser($id_user): bool;
    public function getNextEventsDatas(): array;
    public function getRegistredUsers($id_event): array;
    public function getUsers(): array;
    public function getEventDatas($id_event): array;
    public function updateEvent($id_event, $venue, $date, $beginTime, $endTime): bool;
    public function updateUser($id_user, $firstname, $lastname, $email, $mobile, $password): bool;
}