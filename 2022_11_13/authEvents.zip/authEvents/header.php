<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
    <div class="container">
        <a class="navbar-brand">Exemple d'authentification PHP</a>

        <div class="collapse navbar-collapse" id="navbarColor02">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="EventsList.php">Évènements</a>
                </li>
                <?php if (isset($_SESSION["is_logged"])) : ?>
                    <li class="nav-item">
                        <a class="nav-link" href="un-registration.php">(dé)-inscription(s)</a>
                    </li>
                <?php endif; ?>
                <?php if (isset($_SESSION["is_logged"]) && $_SESSION["is_admin"]) : ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">Gestion</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="collapse navbar-collapse" id="navbarColor02">
            <ul class="navbar-nav ml-auto">
                <?php if (!isset($_SESSION["is_logged"])) : ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Connexion</a>
                    </li>
                <?php endif; ?>
                <?php if (isset($_SESSION["is_logged"]) && $_SESSION["is_admin"]) : ?>   
                    <li class="nav-item">
                        <a class="nav-link" href="signup.php">Créer un compte</a>
                    </li>
                <?php endif; ?>
                <?php if (isset($_SESSION["is_logged"])) : ?>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Déconnexion</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>