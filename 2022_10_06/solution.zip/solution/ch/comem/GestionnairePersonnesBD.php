<?php

namespace ch\comem;

/**
 * Gestionnaire permettant la navigation de personnes provenant d'une base de donnée.
 */
class GestionnairePersonnesBD implements IGestionnairePersonnes {
    /*
    Voici les commandes SQL pour la base de données MySQL :
    CREATE TABLE personnes(
       no_client INT NOT NULL,
       prenom VARCHAR (20) NOT NULL,
       nom VARCHAR (20) NOT NULL,
       adresse VARCHAR (50) NOT NULL,
       npa INT NOT NULL,
       ville VARCHAR (30) NOT NULL,
       no_tel VARCHAR (17) NOT NULL,
       PRIMARY KEY (no_client));
       
    ALTER TABLE personnes MODIFY COLUMN no_client INT auto_increment;

    INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
    VALUES ('Jo', 'Bar', 'Rue du Moulin 10', 1000, 'Lausanne', '021/101''02''03');

    INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
    VALUES ('Lise', 'Teriose', 'Rue Coco 20', 2000, 'Neuchâtel', '032/201''02''03');

    INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
    VALUES ('Schwimmklub', 'Bern', 'Postfach 626', 3000, 'Berne', '031/301''02''03');

    INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
    VALUES ('Holly', 'Ballon', 'Ballonfahrten', 4000, 'Basel', '061/401''02''03'); 
    */
    private $db;
    private $index;

    /**
     * Construit le gestionnaire
     */
    public function __construct() {
        $config = parse_ini_file('config' . DIRECTORY_SEPARATOR . 'db_config.ini', true);
        $dsn = $config['database']['dsn'];
        $username = $config['database']['username'];
        $password = $config['database']['password'];
        $this->db = new \PDO($dsn, $username, $password);
        if (!$this->db) {
            die("Problème de connection à la base de données");
        }
    }

    /**
     * Rend la première personne
     * @return \ch\comem\Personne La 1e personne
     */
    public function rendPremier(): Personne {

        $personne = null;
        $sql = "SELECT * FROM personnes WHERE no_client = (SELECT MIN(no_client) FROM personnes);";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        if ($personneDB = $stmt->fetch()) {
            $this->index = $personneDB['no_client'];
            $personne = new Personne($personneDB['no_client'], $personneDB['prenom'], $personneDB['nom'], $personneDB['adresse'], $personneDB['npa'], $personneDB['ville'], $personneDB['no_tel']);
        }

        return $personne;
    }

    /**
     * Rend la personne précédant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant avant l'index
     */
    public function rendPrecedant(int $index): Personne {
        $personne = null;
        $sql = "SELECT * FROM personnes WHERE no_client = (SELECT MAX(a.no_client) FROM (SELECT * FROM personnes WHERE no_client < :no_client) a);";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam('no_client', $index, \PDO::PARAM_INT);
        $stmt->execute();
        if ($personneDB = $stmt->fetch()) {
            $this->index = $personneDB['no_client'];
            $personne = new Personne($personneDB['no_client'], $personneDB['prenom'], $personneDB['nom'], $personneDB['adresse'], $personneDB['npa'], $personneDB['ville'], $personneDB['no_tel']);
        } else {
            return $this->rendPremier();
        }
        return $personne;
    }

    /**
     * Rend la personne suivant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant après l'index
     */
    public function rendSuivant(int $index): Personne {
        $personne = null;
        $sql = "SELECT * FROM personnes WHERE no_client > :no_client LIMIT 1;";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam('no_client', $index, \PDO::PARAM_INT);
        $stmt->execute();
        if ($personneDB = $stmt->fetch()) {
            //var_dump($personne);
            $this->index = $personneDB['no_client'];
            $personne = new Personne($personneDB['no_client'], $personneDB['prenom'], $personneDB['nom'], $personneDB['adresse'], $personneDB['npa'], $personneDB['ville'], $personneDB['no_tel']);
        } else {
            return $this->rendDernier();
        }

        return $personne;
    }

    /**
     * Rend la dernière personne
     * @return \ch\comem\Personne La dernière personne
     */
    public function rendDernier(): Personne {
        $personne = null;
        $sql = "SELECT * FROM personnes WHERE no_client = (SELECT MAX(no_client) FROM personnes);";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        if ($personneDB = $stmt->fetch()) {
            //var_dump($personne);
            $this->index = $personneDB['no_client'];
            $personne = new Personne($personneDB['no_client'], $personneDB['prenom'], $personneDB['nom'], $personneDB['adresse'], $personneDB['npa'], $personneDB['ville'], $personneDB['no_tel']);
        }
        return $personne;
    }

    /**
     * Rend l'index de la personne courante
     * @return int L'index de la personne courante
     */
    public function rendIndex(): int {
        return $this->index;
    }

    /**
     * Rend une chaîne de caractère décrivant la provenance des données
     * @return string "(Données de la DB)"
     */
    public function rendProvenanceDesDonnees(): string {
        return "(Données de la DB)";
    }
}