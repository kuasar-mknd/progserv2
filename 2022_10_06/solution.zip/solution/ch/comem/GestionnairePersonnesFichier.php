<?php

namespace ch\comem;

class GestionnairePersonnesFichier implements IGestionnairePersonnes {

    private $index;
	private $tabPersonnes;

    /**
     * Construit le gestionnaire
     */
    public function __construct() {
        $tabPersonnes = array();
        $fichier = 'datas' . DIRECTORY_SEPARATOR . 'donnees_personnes.txt';
        $lignes = file($fichier);
        foreach ($lignes as $ligne) {
			$p = explode(",", $ligne);
            $this->tabPersonnes[] = new Personne($p[0], $p[1], $p[2], $p[3], $p[4], $p[5], $p[6]);
        }
		$this->index = 0;
    }

    /**
     * Rend la première personne
     * @return \ch\comem\Personne La 1e personne
     */
    public function rendPremier(): Personne {
        return $this->tabPersonnes[0];
    }

    /**
     * Rend la personne précédant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant avant l'index
     */
    public function rendPrecedant(int $index): Personne {
        $this->index = max($index - 1, 0);
        return $this->tabPersonnes[$this->index];
    }

    /**
     * Rend la personne suivant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant après l'index
     */
    public function rendSuivant(int $index): Personne {
        $this->index = min(count($this->tabPersonnes)-1, $index + 1);
        return $this->tabPersonnes[$this->index];
    }

    /**
     * Rend la dernière personne
     * @return \ch\comem\Personne La dernière personne
     */
    public function rendDernier(): Personne {
        $this->index = count($this->tabPersonnes)-1;
        return $this->tabPersonnes[$this->index];
    }

    /**
     * Rend l'index de la personne courante
     * @return int L'index de la personne courante
     */
    public function rendIndex(): int {
        return $this->index;
    }

    /**
     * Rend une chaîne de caractère décrivant la provenance des données
     * @return string "(Données du fichier)"
     */
    public function rendProvenanceDesDonnees(): string {
        return "(Données du fichier)";
    }
}