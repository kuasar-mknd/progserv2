<?php

namespace ch\comem;

/**
 * Décrit les fonctionnalités d'un gestionnaire de personnes
 */
interface IGestionnairePersonnes {

    /**
     * Rend la première personne
     * @return \ch\comem\Personne La 1e personne
     */
    public function rendPremier(): Personne;

    /**
     * Rend la personne précédant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant avant l'index
     */
    public function rendPrecedant(int $index): Personne;

    /**
     * Rend la personne suivant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant après l'index
     */
    public function rendSuivant(int $index): Personne;

    /**
     * Rend la dernière personne
     * @return \ch\comem\Personne La dernière personne
     */
    public function rendDernier(): Personne;

    /**
     * Rend l'index de la personne courante
     * @return int L'index de la personne courante
     */
    public function rendIndex(): int;
    
    /**
     * Rend une chaîne de caractère décrivant la provenance des données
     * @return string La chaîne descriptive
     */
    public function rendProvenanceDesDonnees(): string;
}