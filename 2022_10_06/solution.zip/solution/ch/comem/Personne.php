<?php

namespace ch\comem;

use \Exception;

class Personne {

    private $noClient;
    private $nom;
    private $prenom;
    private $adresse;
    private $npa;
    private $ville;
    private $noTel;

    /**
     * Construit une nouvelle personne avec les paramètres spécifiés
     * @param int $noClient Numéro de client
     * @param string $prenom Prénom
     * @param string $nom Nom
     * @param string $adresse Adresse
     * @param int $npa Npa
     * @param string $ville Ville
     * @param string $noTel Numéro de téléphone
     * @throws Exception Lance une expection si un des paramètres n'est pas spécifié
     */
    public function __construct(int $noClient, string $prenom, string $nom, string $adresse, int $npa, string $ville, string $noTel) {
        if ($noClient <= 0) {
            throw new Exception('Il faut un numéro de client valide');
        }
        if (empty($prenom)) {
            throw new Exception('Il faut un prénom');
        }
        if (empty($nom)) {
            throw new Exception('Il faut un nom');
        }
        if (empty($adresse)) {
            throw new Exception('Il faut une adresse');
        }
        if ($npa <= 0) {
            throw new Exception('Il faut un npa valide');
        }
        if (empty($ville)) {
            throw new Exception('Il faut une ville');
        }
        if (empty($noTel)) {
            throw new Exception('Il faut un numéro de téléphone');
        }

        $this->noClient = $noClient;
        $this->prenom = $prenom;
        $this->nom = $nom;
        $this->adresse = $adresse;
        $this->npa = $npa;
        $this->ville = $ville;
        $this->noTel = $noTel;
    }

    /**
     * Rend le numéro de client
     * @return int Le numéro de client
     */
    public function rendNoClient(): int {
        return $this->noClient;
    }

    /**
     * Rend le prénom
     * @return string Le prénom
     */
    public function rendPrenom(): string {
        return $this->prenom;
    }

    /**
     * Rend le nom
     * @return string Le nom
     */
    public function rendNom(): string {
        return $this->nom;
    }

    /**
     * Rend l'adresse
     * @return string L'adresse
     */
    public function rendAdresse(): string {
        return $this->adresse;
    }

    /**
     * Rend le numéro postal
     * @return int Le npa
     */
    public function rendNpa(): int {
        return $this->npa;
    }

    /**
     * Rend la ville
     * @return string La ville
     */
    public function rendVille(): string {
        return $this->ville;
    }

    /**
     * Rend le numéro de téléphone
     * @return string Le numéro de téléphone
     */
    public function rendNoTel(): string {
        return $this->noTel;
    }

    /**
     * Rend une description complète de la personne
     * @return string La description de la personne
     */
    public function __toString(): string {
        return $this->noClient . " " .
                $this->prenom . " " .
                $this->nom . " " .
                $this->adresse . " " .
                $this->npa . " " .
                $this->ville . " " .
                $this->noTel . '<br>';
    }
}