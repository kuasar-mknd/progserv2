<?php

require_once('config/autoload.php'); // permet le chargement automatique des classes utilisées

//$gest = new ch\comem\GestionnairePersonnesBD(); 
$gest = new ch\comem\GestionnairePersonnesFichier();

if (filter_has_var(INPUT_POST, 'submitPremier')) {
    $p = $gest->rendPremier();
} elseif (filter_has_var(INPUT_POST, 'submitPrecedant')) {
    $index = filter_input(INPUT_POST, 'index', FILTER_VALIDATE_INT);
    $p = $gest->rendPrecedant($index);
} elseif (filter_has_var(INPUT_POST, 'submitSuivant')) {
    $index = filter_input(INPUT_POST, 'index', FILTER_VALIDATE_INT);
    $p = $gest->rendSuivant($index);
} elseif (filter_has_var(INPUT_POST, 'submitDernier')) {
    $p = $gest->rendDernier();
} else {
    $p = $gest->rendPremier();
}

echo $gest->rendProvenanceDesDonnees() . "<br>
  No client : " . $p->rendNoClient() . "<br>
  Prenom : " . $p->rendPrenom() . "<br>
  Nom : " . $p->rendNom() . "<br>
  Adresse : " . $p->rendAdresse() . "<br>
  Npa : " . $p->rendNpa() . "<br>
  Ville : " . $p->rendVille() . "<br>
  Téléphone : " . $p->rendNoTel() . "<br><br>";

$form = "<form method='post' action='" . htmlspecialchars($_SERVER['PHP_SELF']) . "'>
    <input type='hidden' name='index' value=" . $gest->rendIndex() . " />
    <input type='submit' name='submitPremier' value='<<' >
    <input type='submit' name='submitPrecedant' value='<' >
    <input type='submit' name='submitSuivant' value='>' >
    <input type='submit' name='submitDernier' value='>>' > 
  </form>";

echo $form, '<br>';