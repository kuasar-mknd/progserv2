# Exercice 1

Soit des clients définis par :

```
   - noClient
   - nom
   - prénom
   - adresse
   - npa
   - ville
   - tel
```

Ecrire un code PHP (utilisant la notion d'interface) mettant à disposition un formulaire permettant d'afficher les données d'un client à la fois une barre de navigation (boutons) doit être affichée permettant de passer d'un client à l'autre.
Les données d'un client peuvent provenir soit dans une base de donnée, soit d'un fichier texte (Un client par ligne, champs séparés par des points virgules)
Le code à rendre doit permettre de ne changer qu'une seule ligne pour passer des données de la base de donnée à celles du fichier.
Le code doit être documenté de manière à ce qu'une documentation `html` puisse être générée par l'outil `phpDocumentor`

```
   No client : 324567
   Nom       : Dumoulin
   Prénom    : Jean
   Adresse   : Rue du moulin 2
   Npa       : 1000
   Ville     : Lausanne
   Tél       : 021 123 45 67

   <<     <     >     >>       (Barre de navigation)
```

Le bouton `<<` doit permettre d'afficher le 1er client
Le bouton `<` doit permettre d'afficher le client précédant
Le bouton `>` doit permettre d'afficher le client suivant
Le bouton `>>` doit permettre d'afficher le dernier client