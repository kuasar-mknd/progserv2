<?php

namespace ch\comem;

use \Exception;

/**
 * Décrit les fonctionnalités d'un gestionnaire de personnes
 */
interface IGestionnairePersonnes {

    /**
     * Rend la première personne
     * @return \ch\comem\Personne La 1e personne
     */
    public function rendPremier(): Personne;

    /**
     * Rend la personne précédant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant avant l'index
     */
    public function rendPrecedant(int $index): Personne;

    /**
     * Rend la personne suivant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant après l'index
     */
    public function rendSuivant(int $index): Personne;

    /**
     * Rend la dernière personne
     * @return \ch\comem\Personne La dernière personne
     */
    public function rendDernier(): Personne;

    /**
     * Rend l'index de la personne courante
     * @return int L'index de la personne courante
     */
    public function rendIndex(): int;
    
    /**
     * Rend une chaîne de caractère décrivant la provenance des données
     * @return string La chaîne descriptive
     */
    public function rendProvenanceDesDonnees(): string;
}

class Personne {

    private $noClient;
    private $nom;
    private $prenom;
    private $adresse;
    private $npa;
    private $ville;
    private $noTel;

    /**
     * Construit une nouvelle personne avec les paramètres spécifiés
     * @param int $noClient Numéro de client
     * @param string $prenom Prénom
     * @param string $nom Nom
     * @param string $adresse Adresse
     * @param int $npa Npa
     * @param string $ville Ville
     * @param string $noTel Numéro de téléphone
     * @throws Exception Lance une expection si un des paramètres n'est pas spécifié
     */
    public function __construct(int $noClient, string $prenom, string $nom, string $adresse, int $npa, string $ville, string $noTel) {
        if ($noClient <= 0) {
            throw new Exception('Il faut un numéro de client valide');
        }
        if (empty($prenom)) {
            throw new Exception('Il faut un prénom');
        }
        if (empty($nom)) {
            throw new Exception('Il faut un nom');
        }
        if (empty($adresse)) {
            throw new Exception('Il faut une adresse');
        }
        if ($npa <= 0) {
            throw new Exception('Il faut un npa valide');
        }
        if (empty($ville)) {
            throw new Exception('Il faut une ville');
        }
        if (empty($noTel)) {
            throw new Exception('Il faut un numéro de téléphone');
        }

        $this->noClient = $noClient;
        $this->prenom = $prenom;
        $this->nom = $nom;
        $this->adresse = $adresse;
        $this->npa = $npa;
        $this->ville = $ville;
        $this->noTel = $noTel;
    }

    /**
     * Rend le numéro de client
     * @return int Le numéro de client
     */
    public function rendNoClient(): int {
        return $this->noClient;
    }

    /**
     * Rend le prénom
     * @return string Le prénom
     */
    public function rendPrenom(): string {
        return $this->prenom;
    }

    /**
     * Rend le nom
     * @return string Le nom
     */
    public function rendNom(): string {
        return $this->nom;
    }

    /**
     * Rend l'adresse
     * @return string L'adresse
     */
    public function rendAdresse(): string {
        return $this->adresse;
    }

    /**
     * Rend le numéro postal
     * @return int Le npa
     */
    public function rendNpa(): int {
        return $this->npa;
    }

    /**
     * Rend la ville
     * @return string La ville
     */
    public function rendVille(): string {
        return $this->ville;
    }

    /**
     * Rend le numéro de téléphone
     * @return string Le numéro de téléphone
     */
    public function rendNoTel(): string {
        return $this->noTel;
    }

    /**
     * Rend une description complète de la personne
     * @return string La description de la personne
     */
    public function __toString(): string {
        return $this->noClient . " " .
                $this->prenom . " " .
                $this->nom . " " .
                $this->adresse . " " .
                $this->npa . " " .
                $this->ville . " " .
                $this->noTel . '<br>';
    }
}

class GestionnairePersonnesFichier implements IGestionnairePersonnes {

    private $index;
	private $tabPersonnes;

    /**
     * Construit le gestionnaire
     */
    public function __construct($index = -1) {
        $tabPersonnes = array();
        $fichier = 'datas\donnees_personnes.txt';
        $lignes = file($fichier);
        foreach ($lignes as $ligne) {
			$p = explode(",", $ligne);
            $this->tabPersonnes[] = new Personne($p[0], $p[1], $p[2], $p[3], $p[4], $p[5], $p[6]);
        }
		$this->index = 0;
    }

    /**
     * Rend la première personne
     * @return \ch\comem\Personne La 1e personne
     */
    public function rendPremier(): Personne {
        return $this->tabPersonnes[0];
    }

    /**
     * Rend la personne précédant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant avant l'index
     */
    public function rendPrecedant(int $index): Personne {
        $this->index = max($index - 1, 0);
        return $this->tabPersonnes[$this->index];
    }

    /**
     * Rend la personne suivant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant après l'index
     */
    public function rendSuivant(int $index): Personne {
        $this->index = min(count($this->tabPersonnes)-1, $index + 1);
        return $this->tabPersonnes[$this->index];
    }

    /**
     * Rend la dernière personne
     * @return \ch\comem\Personne La dernière personne
     */
    public function rendDernier(): Personne {
        $this->index = count($this->tabPersonnes)-1;
        return $this->tabPersonnes[$this->index];
    }

    /**
     * Rend l'index de la personne courante
     * @return int L'index de la personne courante
     */
    public function rendIndex(): int {
        return $this->index;
    }

    /**
     * Rend une chaîne de caractère décrivant la provenance des données
     * @return string "(Données du fichier)"
     */
    public function rendProvenanceDesDonnees(): string {
        return "(Données du fichier)";
    }
}

/**
 * Gestionnaire permettant la navigation de personnes provenant d'une base de donnée.
 */
class GestionnairePersonnesBD implements IGestionnairePersonnes {
    /*
    Voici les commandes SQL pour peupler la base de données :
    CREATE TABLE personnes(
       no_client INT NOT NULL,
       prenom VARCHAR (20) NOT NULL,
       nom VARCHAR (20) NOT NULL,
       adresse VARCHAR (50) NOT NULL,
       npa INT NOT NULL,
       ville VARCHAR (30) NOT NULL,
       no_tel VARCHAR (17) NOT NULL,
       PRIMARY KEY (no_client));
       
    ALTER TABLE personnes MODIFY COLUMN no_client INT auto_increment;

    INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
    VALUES ('Jo', 'Bar', 'Rue du Moulin 10', 1000, 'Lausanne', '021/101''02''03');

    INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
    VALUES ('Lise', 'Teriose', 'Rue Coco 20', 2000, 'Neuchâtel', '032/201''02''03');

    INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
    VALUES ('Schwimmklub', 'Bern', 'Postfach 626', 3000, 'Berne', '031/301''02''03');

    INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
    VALUES ('Holly', 'Ballon', 'Ballonfahrten', 4000, 'Basel', '061/401''02''03'); 
    */
    private $db;
    private $index;

    /**
     * Construit le gestionnaire
     */
    public function __construct() {
        $config = parse_ini_file('config\db_config.ini', true);
        $dsn = $config['database']['dsn'];
        $username = $config['database']['username'];
        $password = $config['database']['password'];
        $this->db = new \PDO($dsn, $username, $password);
        if (!$this->db) {
            die("Problème de connection à la base de données");
        }
    }

    /**
     * Rend la première personne
     * @return \ch\comem\Personne La 1e personne
     */
    public function rendPremier(): Personne {

        $personne = null;
        $sql = "SELECT * FROM personnes WHERE no_client = (SELECT MIN(no_client) FROM personnes);";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        if ($personneDB = $stmt->fetch()) {
            $this->index = $personneDB['no_client'];
            $personne = new Personne($personneDB['no_client'], $personneDB['prenom'], $personneDB['nom'], $personneDB['adresse'], $personneDB['npa'], $personneDB['ville'], $personneDB['no_tel']);
        }

        return $personne;
    }

    /**
     * Rend la personne précédant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant avant l'index
     */
    public function rendPrecedant(int $index): Personne {
        $personne = null;
        $sql = "SELECT * FROM personnes WHERE no_client = (SELECT MAX(a.no_client) FROM (SELECT * FROM personnes WHERE no_client < :no_client) a);";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam('no_client', $index, \PDO::PARAM_INT);
        $stmt->execute();
        if ($personneDB = $stmt->fetch()) {
            $this->index = $personneDB['no_client'];
            $personne = new Personne($personneDB['no_client'], $personneDB['prenom'], $personneDB['nom'], $personneDB['adresse'], $personneDB['npa'], $personneDB['ville'], $personneDB['no_tel']);
        } else {
            return $this->rendPremier();
        }
        return $personne;
    }

    /**
     * Rend la personne suivant l'index spécifé
     * @param int $index L'index référence
     * @return \ch\comem\Personne La personne se trouvant après l'index
     */
    public function rendSuivant(int $index): Personne {
        $personne = null;
        $sql = "SELECT * FROM personnes WHERE no_client > :no_client LIMIT 1;";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam('no_client', $index, \PDO::PARAM_INT);
        $stmt->execute();
        if ($personneDB = $stmt->fetch()) {
            //var_dump($personne);
            $this->index = $personneDB['no_client'];
            $personne = new Personne($personneDB['no_client'], $personneDB['prenom'], $personneDB['nom'], $personneDB['adresse'], $personneDB['npa'], $personneDB['ville'], $personneDB['no_tel']);
        } else {
            return $this->rendDernier();
        }

        return $personne;
    }

    /**
     * Rend la dernière personne
     * @return \ch\comem\Personne La dernière personne
     */
    public function rendDernier(): Personne {
        $personne = null;
        $sql = "SELECT * FROM personnes WHERE no_client = (SELECT MAX(no_client) FROM personnes);";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        if ($personneDB = $stmt->fetch()) {
            //var_dump($personne);
            $this->index = $personneDB['no_client'];
            $personne = new Personne($personneDB['no_client'], $personneDB['prenom'], $personneDB['nom'], $personneDB['adresse'], $personneDB['npa'], $personneDB['ville'], $personneDB['no_tel']);
        }
        return $personne;
    }

    /**
     * Rend l'index de la personne courante
     * @return int L'index de la personne courante
     */
    public function rendIndex(): int {
        return $this->index;
    }

    /**
     * Rend une chaîne de caractère décrivant la provenance des données
     * @return string "(Données de la DB)"
     */
    public function rendProvenanceDesDonnees(): string {
        return "(Données de la DB)";
    }

}

$gest = new GestionnairePersonnesBD();
//$gest = new GestionnairePersonnesFichier();

if (filter_has_var(INPUT_POST, 'submitPremier')) {
    $p = $gest->rendPremier();
} elseif (filter_has_var(INPUT_POST, 'submitPrecedant')) {
    $index = filter_input(INPUT_POST, 'index', FILTER_VALIDATE_INT);
    $p = $gest->rendPrecedant($index);
} elseif (filter_has_var(INPUT_POST, 'submitSuivant')) {
    $index = filter_input(INPUT_POST, 'index', FILTER_VALIDATE_INT);
    $p = $gest->rendSuivant($index);
} elseif (filter_has_var(INPUT_POST, 'submitDernier')) {
    $p = $gest->rendDernier();
} else {
    $p = $gest->rendPremier();
}

echo $gest->rendProvenanceDesDonnees() . "<br>
  No client : " . $p->rendNoClient() . "<br>
  Prenom : " . $p->rendPrenom() . "<br>
  Nom : " . $p->rendNom() . "<br>
  Adresse : " . $p->rendAdresse() . "<br>
  Npa : " . $p->rendNpa() . "<br>
  Ville : " . $p->rendVille() . "<br>
  Téléphone : " . $p->rendNoTel() . "<br><br>";

$form = "<form method='post' action='" . htmlspecialchars($_SERVER['PHP_SELF']) . "'>
    <input type='hidden' name='index' value=" . $gest->rendIndex() . " />
    <input type='submit' name='submitPremier' value='<<' >
    <input type='submit' name='submitPrecedant' value='<' >
    <input type='submit' name='submitSuivant' value='>' >
    <input type='submit' name='submitDernier' value='>>' > 
  </form>";

echo $form, '<br>';