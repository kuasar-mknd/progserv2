CREATE TABLE personnes(
       no_client INT NOT NULL,
       prenom VARCHAR (20) NOT NULL,
       nom VARCHAR (20) NOT NULL,
       adresse VARCHAR (50) NOT NULL,
       npa INT NOT NULL,
       ville VARCHAR (30) NOT NULL,
       no_tel VARCHAR (17) NOT NULL,
       PRIMARY KEY (no_client));
       
ALTER TABLE personnes MODIFY COLUMN no_client INT auto_increment;

INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
VALUES ('Jo', 'Bar', 'Rue du Moulin 10', 1000, 'Lausanne', '021/101''02''03');

INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
VALUES ('Lise', 'Teriose', 'Rue Coco 20', 2000, 'Neuchâtel', '032/201''02''03');

INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
VALUES ('Schwimmklub', 'Bern', 'Postfach 626', 3000, 'Berne', '031/301''02''03');

INSERT INTO personnes (prenom, nom, adresse, npa, ville, no_tel)
VALUES ('Holly', 'Ballon', 'Ballonfahrten', 4000, 'Basel', '061/401''02''03'); 